## Esta es la idea de mi proyecto:
>**Contaminacion por el efecto invernadero**

>1.Trataria de desarrollar un tipo de web e intentar que se vuelva popular para que llegue a mucha gente.Esta web o aplicacion tendria como objetivo reducir el cambio climatico por la contaminacion por el efecto invernadero.

>2.Hacer que los usuarios se puedan reunir en lugar de la ciudad o el pais para realizar actividades buenas para el medio ambiente,como plantar arboles y mucahs cosas más.Todo esto con el objetivo de crear una comunidad grande y reconocida para que la contaminacion en el planeta se reduzca.

>3.Esto estaria dirigido al publico adulto ya que los niños y adolescentes no comprenderian ya que son muy jovenes y no tienen una perspectiva completa del estado actual de la tierra en cambio los adultos son mas sabios ya que son mas grandes y al final los adultos deberian enseñarle a los jovenes.


>4.Estas serian las herramientas que usaria:
- Explorar la documentación de la biblioteca
- Archivos y carpetas
- Entornos virtuales
**Conceptos básicos del diseño web**
- HTML + CSS
- Plantillas Flask
- Variables Jinja 
- Enrutamiento web
- Sqlalchemy


>**Este seria el README de mi proyecto de graduacion espero que le guste al que lo lea.**