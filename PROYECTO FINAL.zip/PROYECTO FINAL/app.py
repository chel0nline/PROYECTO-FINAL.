from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# Configuración de la aplicación
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)

# Modelo de usuario
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

# Ruta de inicio (home)
@app.route('/')
def home():
    return render_template('home.html')

# Registro
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if not username or not email or not password or not confirm_password:
            flash('Todos los campos son obligatorios.', 'danger')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Las contraseñas no coinciden.', 'danger')
            return redirect(url_for('register'))

        # Verifica si el email ya está registrado
        if User.query.filter_by(email=email).first():
            flash('El correo ya está registrado.', 'danger')
            return redirect(url_for('register'))

        # Usar pbkdf2:sha256 para el hashing
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        flash('¡Registro exitoso! Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# Ruta de inicio de sesión
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Verificar usuario y contraseña
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id  # Guardamos el ID del usuario en la sesión
            return redirect(url_for('perfil'))  # Redirigimos al perfil
        else:
            flash('Usuario o contraseña incorrectos.', 'danger')

    return render_template('login.html')

# Ruta del perfil
@app.route('/perfil')
def perfil():
    if 'user_id' not in session:
        flash('Debes iniciar sesión primero.', 'danger')
        return redirect(url_for('login'))  # Si el usuario no ha iniciado sesión, redirige al login.
    
    # Aquí puedes obtener la información del perfil de la base de datos si es necesario
    user = User.query.get(session['user_id'])  # Obtener el usuario de la sesión
    return render_template('perfil.html', user=user)  # Pasamos el usuario a la plantilla

# Cerrar sesión
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Has cerrado sesión.', 'success')
    return redirect(url_for('home'))

# Siguiente sección
@app.route('/seccion1')
def seccion1():
    return render_template('seccion1.html')  # O la lógica que quieras para esta sección

# Sección número 2
@app.route('/seccion2')
def seccion2():
    return render_template('seccion2.html')

@app.route('/seccion3')
def seccion3():
    return render_template('seccion3.html')

@app.route('/links')
def links():
    return render_template('links.html')

@app.route('/agradecimiento')
def agradecimiento():
    return render_template('agradecimiento.html')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()  #Crea la base de datos si no existe
    app.run(debug=True)

